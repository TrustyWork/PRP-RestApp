var mongoose = require( 'mongoose');
var Schema = mongoose.Schema;

var redactSchema = new Schema({
    text: {type: String}
}, {collection: 'user-texts'});


var RedactModel = mongoose.model('RedactModel', redactSchema)
module.exports = RedactModel;