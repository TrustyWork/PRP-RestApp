var mongoose = require( 'mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    Name: {type: String, required: true},
    Surname: {type: String, required: true},
    Birthday: {type: Date},
}, {collection: 'user-data'});

userSchema.methods.getFullName = function () {
    var fullName = this.Name + ' ' + this.Surname
    return fullName;
}

userSchema.methods.getAge = function () {
    if(this.Birthday==null){
        var errmsg = 'Unknown birthday';
        return errmsg;
    }
    var now = new Date();

    var age = now.getFullYear() - this.Birthday.getFullYear();
    if(age >= 0) {
         var months = now.getMonth() - this.Birthday.getMonth();
        if(months > 0) {
            return age;
        } else if(months = 0) {
            var day = now.getDate()- this.Birthday.getDate();
            if(day>0){
                return age;
            } else {
                --age;
                return age;
            }
        } else {
            --age;
            return age;
        }
    } else {
        var errmsg = 'Wrong date of birthday';
        return errmsg;
    };
};

var UserModel = mongoose.model('UserModel', userSchema)
module.exports = UserModel;

