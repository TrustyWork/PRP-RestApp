var express = require('express');
var router = express.Router();
var indexModel = require('../models');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'База Данных' });
});

router.post('/insert', function(req, res, next) {

    var fullname = req.body.username;
    if(!(~fullname.indexOf(' '))) res.render('index', { title: 'Probably, you forgot enter surname. Try again' });
    var nameArr = fullname.split(' ');

    var birthday = req.body.birthday;

    var item = {
        Name: nameArr[0],
        Surname: nameArr[1],
        Birthday: birthday
    };

    var user = new UserModel(item);
    user.save();
    console.log('Data inserted');
    res.render('index', { title: 'Data inserted successfully' });
});


router.get('/findUser', function(req, res, next) {
    console.log('start finding');
    var name = req.query.findUserName;
    console.log(name);

    if(~name.indexOf(' ')) {
        var nameArr = name.split(' ');
        name = nameArr[0];
        var surname = nameArr[1];
    };

    console.log(surname)
    if(!surname) {
        UserModel.find({Name: name}, (err, data) => {
            console.log('data are ' + data);

            if (!data.length) {
                console.log('err finding by name, trying search by surname')

                UserModel.find({Surname: name}, (err, data) => {
                    console.log('in callback is ' + data);
                    if (!data.length) {
                        console.log('err finding surname')
                        res.render('index', {userdata: data, title: 'I\'m failed finding user. Let\'s try once more?'});
                    } else {
                        res.render('index', {userdata: data, title: 'I have found some variants by surname'});
                    }
                });
            } else {
                res.render('index', {userdata: data, title: 'I have found some variants by name'});
            }

        });
    } else {
        UserModel.find({$and: [{Surname: surname}, {Name: name}]}, (err, data) => {
            console.log('in callback is ' + data);
            if (!data.length) {
                console.log('err finding surname')
                res.render('index', {userdata: data, title: 'I\'m failed finding user. Let\'s try once more fullname?'});
            } else {
                res.render('index', {userdata: data, title: 'I have found some variants'});
            }
        });

    }

});

module.exports = router;