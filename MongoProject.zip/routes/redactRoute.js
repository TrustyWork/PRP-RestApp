var express = require('express');
var router = express.Router();
var indexModel = require('../models');

/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('redact');
});


router.post('/puttext', function(req, res, next) {
    console.log(req.body)
    var textvalue = req.body.text;
    console.log(textvalue);   //empty object

    var itemtext = {
        text: 'ii3' //cant get formdata value
    };

    var text = new RedactModel(itemtext);
    text.save();
});

router.post('/putEditorText', function(req, res, next) {
    console.log(req.body)
    var textvalue = req.body.text;
    console.log(textvalue);   //empty object

    var itemtext = {
        text: textvalue //cant get formdata value
    };

    var text = new RedactModel(itemtext);
    text.save();
});

module.exports = router;